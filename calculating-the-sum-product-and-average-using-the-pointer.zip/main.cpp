/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int hi(int *n,int *i);

int main()
{   int n=4;
int i=9;
    hi(&n,&i);
    
    

    return 0;
}
int hi(int *n,int* i){
    int sum,average,product;
   sum=*n+*i;
   average=(*n+*i)/2;
   product=(*n)*(*i);
   cout<<sum<<average<<product<<endl;
    return 0;

}